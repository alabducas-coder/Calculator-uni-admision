@echo off
setlocal
set "APP_FILE=%~dp0app\index.html"
set "APP_URL=%APP_FILE:\=/%"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"
if exist "%EDGE%" (
  start "" "%EDGE%" --app="file:///%APP_URL%?desktop=1" --user-data-dir="%LOCALAPPDATA%\NumaCalculadora" --window-size=1280,900
  exit /b 0
)
start "" "%APP_FILE%"
exit /b 0
